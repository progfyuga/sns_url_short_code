<?php
/*
Plugin Name:  SNS_SHORT_CODEくん
Description: SNSのURLをショートコードで設定できる。グローバル変数として参照できる。グローバル変数の例 : "$tiktok_url", "$instagram_url", "$facebook_url", "$twitter_url".
Version: 1.0
*/

//tiktokのURL設定
function tiktok_url($atts) {
	global $tiktok_url;
	$tiktok_url = $atts['0'];
	return null;
}
add_shortcode('tiktok', 'tiktok_url');

//instagramのURL設定
function instagram_url($atts) {
	global $instagram_url;
	$instagram_url = $atts['0'];
	return null;
}
add_shortcode('instagram', 'instagram_url');

//facebookのURL設定
function facebook_url($atts) {
	global $facebook_url;
	$facebook_url = $atts['0'];
	return null;
}
add_shortcode('facebook', 'facebook_url');

//twitterのURL設定
function twitter_url($atts) {
	global $twitter_url;
	$twitter_url = $atts['0'];
	return null;
}
add_shortcode('twitter', 'twitter_url');